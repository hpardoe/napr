#' Age prediction model
#' generated using rvmm part of kernlab library
#' @format kernlab prediction model
#' @source a bunch of control MRI datasets
"rvmm.fsavg4"